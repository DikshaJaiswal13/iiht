package com.example.stockspring.controller;

public interface UserController {
	
	
	
}
